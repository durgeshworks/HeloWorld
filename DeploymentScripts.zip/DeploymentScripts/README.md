# packer-win-aws
A Packer template for provisioning a windows instance on EC2 using Powershell over WinRM / https
